#ifndef MATHTOOL_H
#define MATHTOOL_H

class MathTool {
    public:
	static int Upper(float data);
};

/*++++++++++++++++++Test++++++++++++++++++*/
void TestUpper();
/*------------------Test------------------*/

#endif